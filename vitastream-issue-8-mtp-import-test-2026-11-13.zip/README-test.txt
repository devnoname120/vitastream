VitaStream issue #8: MTP import-hook test, 2026-11-13

Experimental build; hardware confirmation is pending. This avoids a reproduced Thumb-to-ARM relocation defect in taiHEN's bundled substitute source. The reporter's actual panic PC and installed taiHEN version remain unrecorded.

Restore your usual plugin configuration, including IOStaging if normally used. Both with and without IOStaging reproduced the previous candidate's failure. Keep StorageMgr and its mapping unchanged.
Back up the active VitaStream plugin. Replace that same file with vitastream_diagnostic.skprx, retaining config and one loaded variant. Close PC capture clients and reboot once. Verify:
  USB MTP import schema 0x00000001
  install VitaShell MtpIf import handoff hooks 0x00000000
Open VitaShell 2.02 with SD2Vita selected, press SELECT once. If storage opens, copy one small file, stop storage, and check capture returns. Then check LiveArea unplug/replug still uses VitaStream without the CMA popup. If it fails, stop and save these before another manual reboot:
  ur0:/data/vitastream_usb_diag.txt
  ur0:/data/vitastream_usb_diag.previous.txt
Report exact failure point and whether the two startup records appeared.

Normal build: DEBUG=off, DIAGNOSTIC=off. Diagnostic: DEBUG=off, DIAGNOSTIC=on. Firmware/config/allocation behavior is retained from the prior candidate.
Full source, patch chain against 70c77f5, ELF files, checksums, firmware results, build/test logs and relocation analysis are included. See analysis/README.md for proof and evidence limits. No physical Vita testing by the author. Do not merge artifact-only test-builds into main.
