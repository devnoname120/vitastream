VitaStream issue #9 diagnostic candidate — 2026-11-10

This adds diagnostics, not a claimed fix.
Baseline: 70c77f54bc78a508ade557c232c749f5e12f3371
Diagnostic SKPRX SHA-256: 7c376cebf7dfa72a13ffb75adc5cdd165f7a41dcbedc0ea006761486efe720a7

The package retains the capture behavior of the November 9 current-main build
that reproduced Mario Galaxy's save-load failure. It excludes the later issue
#10 Adrenaline scan-window change and the experimental issue #11 suspend handler.
The normal build from this source is byte-identical to the original baseline;
only the diagnostic binary is supplied here so the new evidence is collected.

New evidence
------------
- Host UVC RESET/PROBE/COMMIT format/frame indices, dimensions and intervals.
- The format/dimensions and committed pacing interval actually used by the worker.
- Owned video allocation size and source owner, geometry, pitch and pixel format.
- Separate errors for process/page leases, address translation, IFTU conversion,
  buffer allocation, USB completion waiting and USB submission.
- Error detail is deduplicated and bounded; ordinary source address swaps do
  not emit per-frame filesystem records. EP0 callbacks queue bounded records
  without allocating or writing files; the video worker drains them.
- On boot, the previous current diagnostic is moved to
  ux0:/data/vitastream_diag.previous.txt. If that rename fails, the new boot
  header is appended instead of truncating the existing evidence.

One requested reproduction
--------------------------
1. Back up the installed streaming plugin. Replace the file at its active
   taiHEN kernel-plugin path with this vitastream_diagnostic.skprx. Keep the
   existing configuration and load only one streaming plugin. Reboot once.
2. Use Windows Camera with the intended 480x272 / 30-fps setting, video only.
   Keep the USB audio input closed. The log will show what the host requests
   and what VitaStream actually uses; no resolution assumption is required.
3. From the fresh boot, launch Mario Galaxy v1.4 and load the same save once.
   Do not enter USB storage or suspend before that attempt.
4. After failure or an automatic reboot, retrieve both files if present:
     ux0:/data/vitastream_diag.txt
     ux0:/data/vitastream_diag.previous.txt
   Please do not manually reboot again before saving them. The previous file
   holds one boot's retained evidence and is replaced by the next boot.
5. Attach the logs and say whether the result was a black screen, an error or
   an automatic reboot. If this run works, report that rather than repeating
   stress cycles. Restore the previous known-working plugin after collecting
   the evidence if the console is unreliable.

A recognized new log contains: video diagnostic schema 0x00000001.
This is an instrumented build and may affect timing; a clean attempt alone
would not prove the underlying bug fixed. If a fatal failure happens before an
operation returns, the log may still not identify the final faulting component.

Verification
------------
- Full host suite with AddressSanitizer and UndefinedBehaviorSanitizer passed.
- Tests cover raw negotiation snapshots, deferred callback logging, source
  swaps without log spam, exact failing conversion stages after cleanup,
  unchanged return values, bounded error detail and previous-boot retention.
- Normal and diagnostic target builds passed without compiler warnings in
  the pinned VitaSDK image. Normal binary equality was checked for both the
  failing baseline and the current main source instrumentation.
- Linked imports/profile checks passed for 31 available firmware/hardware pairs;
  5 archive combinations were unavailable. These are offline checks.
- No physical Vita test was performed with this diagnostic candidate.

Source reproduction
-------------------
source.tar.gz contains complete corresponding source. diagnostics.patch applies
to the baseline commit above; source-sha256.json records the frozen file hashes.
Build in the pinned VitaSDK image with ./gen_builds.sh <output-directory>.
VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
