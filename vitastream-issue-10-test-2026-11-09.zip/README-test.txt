VitaStream issue #10 test candidate — 2026-11-09

Commit: 51d66bf7f2ea82e4f39805913ed1994c53d6f4f1
Base:   70c77f54bc78a508ade557c232c749f5e12f3371
Branch: fix/issue-10-screen-tearing

This is a test build, not a release. The source was analyzed and the automated
host, target-build, and firmware checks passed. It has not yet been tested on a
Vita with Adrenaline, so hardware confirmation is still required.

Static diagnosis
----------------
The supplied recording is not ordinary frame-pacing judder. Affected frames are
horizontal composites: the upper region matches the next frame while the lower
region matches the previous frame, and the split position moves vertically.

Adrenaline's Original filter presents a single 480x272 framebuffer with a pitch
of 512 pixels. SceCompat begins rewriting that surface at the display boundary.
VitaStream v2.3 also wakes its IFTU conversion at that boundary, so IFTU can read
the surface while SceCompat is replacing it from top to bottom.

This build also includes current main's narrowed VitaShell-only USB handoff
and audio startup settling changes. It does not include the experimental
issue #11 manual-suspend handler.

Candidate fix
-------------
- Detect only the exact 480x272, 512-pitch compatibility surface.
- Resolve the SceDisplay scan-position routine at runtime.
- Start capture in a bounded middle-of-scan window, after SceCompat's rewrite
  boundary and before its next one.
- Re-check stream state and re-query the framebuffer after phase alignment so a
  stop, mode change, or source replacement cannot leave stale capture metadata.
- Leave native Vita framebuffers and all other geometries on the existing path.

The scan-position export and its implementation were checked against 31 retail,
testkit, and devkit firmware combinations from 3.60 through 3.74, in the current verification. The implementation was identical in all 31
SceDisplay images.

Files
-----
- vitastream.skprx: normal optimized test build.
- vitastream_diagnostic.skprx: alternative build that writes diagnostics to
  ux0:data/vitastream_diag.txt.
- vitastream.cfg: example configuration; retain your existing configuration.
- vitastream.elf and vitastream_diagnostic.elf: corresponding analysis symbols.
- firmware-matrix.json: firmware/import verification receipt.
- source.tar.gz: complete corresponding source at the commit above.
- build-info.json: build provenance and verification summary.
- SHA256SUMS: SHA-256 digests for all payload files.

Installation
------------
Install ONE SKPRX variant at the existing VitaStream kernel-plugin path, replace
the previous file, and reboot. Do not add a second VitaStream config entry. Use
vitastream.skprx first.

Requested checks
----------------
1. In Adrenaline, select the Original graphics filter and reproduce the same
   games, transitions, and flashing scenes shown in issue #10.
2. Test 960x544 and 864x488 at 60 fps. Record at least several minutes for each
   mode and look specifically for the moving horizontal seam.
3. Also test 30 fps once to detect a cadence-specific regression.
4. Confirm that ordinary native Vita capture still works and that stopping or
   changing the UVC mode does not stall streaming.
5. Report the Vita model, system firmware, Adrenaline version, selected UVC
   resolution/frame rate, and whether any seam remains.

If frames disappear or the seam remains, install the diagnostic variant,
reboot, reproduce once, and attach ux0:data/vitastream_diag.txt together with a
short recording. A repeated capture-phase timeout is logged as error 0x80028005.

Verification completed
----------------------
- Full host test suite passed under AddressSanitizer and UndefinedBehaviorSanitizer.
- Normal and diagnostic ARMv7 SKPRX builds completed in the pinned VitaSDK image.
- Firmware matrix passed: 31 external combinations, five unavailable external images
  recorded, and no device test claimed.

VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
