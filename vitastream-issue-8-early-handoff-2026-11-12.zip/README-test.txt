VitaStream issue #8 early VitaShell handoff test - 2026-11-12

VitaShell's USB kernel module calls ksceUdcdStopCurrentInternal(2) before the
sceMtpIfStopDriver(1) call previously used by VitaStream. The handoff therefore
needs to start before that earlier controller teardown.

This candidate intercepts StopCurrent only for bus 2, ordinary IRQ-enabled
kernel thread context, and a return address inside the loaded
VitaShellUsbDevice text segment. The shared worker handoff drains capture and
suppresses automatic recovery before forwarding the native stop. The existing
VitaShell MtpIf hooks remain for bookkeeping and restoration. Other callers
pass through. Preparation failures retain recovery intent, while the native
already-stopped MTP result accepted by VitaShell allows storage to proceed.

The descriptor ownership/cache reservation fixes remain included. This is an
experimental functional candidate; the SELECT reboot has no faulting-PC trace
and still requires hardware confirmation. Source baseline is 70c77f5 plus the
prior diagnostics, descriptor fix, handoff tracing and early-handoff.patch.

One requested attempt
---------------------
1. Back up the active streaming plugin. Replace the same kernel-plugin file
   with this ZIP's vitastream_diagnostic.skprx, keep the config, load one
   streaming plugin and reboot once. Close PC capture clients for this first
   storage check.
2. Verify USB early handoff schema 0x00000001 in the INTERNAL diagnostic log.
   Open VitaShell and press SELECT once. If it fails, stop and save the logs
   before another manual reboot. State the exact failure point and your
   VitaShell version.
3. If storage opens, copy one small file, stop storage, then check LiveArea
   video/audio capture returns. Save the result and logs. A successful result
   completes this cycle; avoid repeating failure stress.

Log locations CHANGED for this candidate:
  ur0:/data/vitastream_usb_diag.txt
  ur0:/data/vitastream_usb_diag.previous.txt

Internal storage keeps the diagnostic off the usual exported ux0 volume.
The normal plugin is included too, but use the diagnostic for this first check.
Restore the backed-up plugin after collecting evidence if needed.

Expected trace
--------------
Stages 12 and 13 identify the eligible early StopCurrent call. They should
precede the worker drain. Stage 14 forwards native StopCurrent only after the
worker acknowledges completion; stage 15 records its result. The later MtpIf
call uses the existing completed handoff. Existing stages 1 through 11 still
record that wrapper. Additional direct thread-context checkpoints record the
wait and native MTP results on internal storage.

The caller/module identity check and real power/USB behavior require reporter
validation. This build excludes the experimental issue #11 suspend handler
and issue #9 enlarged allocation experiment.

Validation
----------
- Full ASan/UBSan suite passed.
- New host coverage checks early drain before native stop, caller text bounds,
  other callers/buses, IRQ/masked context bypass, repeated preparation, native
  errors, failed preparation recovery intent, accepted MTP already-stopped
  results and partial-hook unload protection.
- Normal/diagnostic target builds passed without warnings in the pinned SDK.
- Offline export/import checks passed for 31 available firmware/hardware pairs,
  including the new StopCurrent export. Five archive combinations are unavailable.
- No physical Vita test has been performed with this candidate.

Complete corresponding source is in source.tar.gz. Starting at 70c77f5, apply
 diagnostics.patch, descriptor-scope.patch, handoff-trace.patch and
 early-handoff.patch. Build normally or with
 make VIDEO_CAMERA_BORROW=1 DIAGNOSTIC=1
using vitasdk/vitasdk@sha256:fd82d88ff456d118eef16533ebf9a3a6ae0e292684fb8a3a35f15f0707b4692d.

VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
