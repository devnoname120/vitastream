VitaStream current-main test candidate — 2026-11-09

Source: 70c77f54bc78a508ade557c232c749f5e12f3371
Branch: main
This is a test build, not a release.

Includes the VitaShell-only storage handoff correction and the initial audio
route settling change. It retains current main's camera-backed buffering,
lowmemory setting, nosleep policy and automatic capture restoration.
It does not contain the experimental issue #11 suspend handler or issue #10
Adrenaline scan-phase change.

Installation
------------
Back up the existing plugin. Replace that file with ONE included SKPRX variant
at the same configured kernel-plugin path, then reboot. Start with vitastream.skprx.
Do not load another streaming plugin alongside it. Keep the existing
vitastream.cfg; the supplied file is an example, not a required replacement.

Requested focused checks
------------------------
- Issue #8: normal LiveArea USB capture without a CMA connecting popup; then
  VitaShell storage, a file transfer, storage stop and capture restoration.
  Check unplug/replug once and ordinary software reboot/power-off.
- Issue #9: distinguish a Mario Galaxy video-only launch after a fresh boot
  from an application switch after suspend/resume. The old broad MTP interception
  is removed, but the application-launch reboot is not claimed fixed.
- Issue #11: this is a corrected baseline, not a claimed manual-suspend fix.
  Record whether the screen wakes by itself or only the blue PS light remains,
  how long that lasts, and whether capture returns after intentional wake.
- Local playback: USB audio should be clean on the PC and Vita speakers. The
  initial two transition blocks are discarded before the local relay starts;
  confirmation of the reported metallic speaker distortion remains pending.

If needed, replace the normal file with vitastream_diagnostic.skprx and reboot.
Save ux0:/data/vitastream_diag.txt before another reboot resets it. Include the
exact VitaStream build, model, firmware, capture app, resolution and sequence.
For ordinary use after a failed test, restore the previous known-working plugin
and reboot. Do not repeat stress cycles after a failure.

Validation
----------
The source's full host suite passed with ASan/UBSan; both target builds passed
with the pinned VitaSDK image. Firmware/import verification was repeated for
31 available retail/testkit/devkit combinations from 3.60 through 3.74; five
archive combinations remain unavailable. Firmware checks are not device tests.
The normal candidate was installed on a retail 3.60 unit with matching readback
and USB reconnection after reboot. That does not validate the reporter's 3.65
storage, power, suspend or Mario Galaxy cases, or audible speaker quality.

VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
