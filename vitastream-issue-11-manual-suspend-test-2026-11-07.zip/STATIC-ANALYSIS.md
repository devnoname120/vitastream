# Issue #11 static analysis

## Observed failure

The reporter's diagnostic (`vitastream_diag-wake.up.txt`, SHA-256
`b08c091e5e25ebb84b3fa8d27c313291ef819fc96d6358cb6643318a9b0c65fa`)
shows active UVC/UAC capture entering teardown around the suspend transition,
followed after the immediate wake by an audio monitor drain failure and a worker
restart timeout. The symptom predates the `nosleep` option and disappears when
the USB cable is removed.

## Firmware evidence

The source of truth was decrypted firmware, with the local Henkaku dump used
only for naming/cross-reference support.

Official retail firmware 3.65 `ScePower` dispatches the relevant system events
in this order:

- suspend gate `0x100` at text address `0x810011e0`;
- suspend abort `0x101` at `0x81001564`;
- native USB resume phase `0x100000` at `0x81001896`;
- final resume `0x400000` at `0x8100195c`.

Official retail 3.65 `SceUsbServ` registers a system-event handler. Its callback
handles later USB phases, including event `0x200` and event `0x400E`, and wakes
native USB service state at resume event `0x100000`. It does not deactivate
VitaStream's separately registered custom UVC UDCD driver at the initial
`0x100` suspend gate.

The 3.60 enriched UDCD database and the debug-rich 4.00 image show that an
active custom controller continues handling host suspend/resume/reset interrupt
state. `ksceUdcdDeactivate`, followed by stopping the custom driver and
`USBDeviceControllerDriver`, removes that active wake-capable path.

The kernel system-event ABI used by Sony modules is:

- library `SceKernelSuspendForDriver`, NID `0x7290B21C`;
- register function NID `0x04C05D10`;
- unregister function NID `0xDD61D621`.

Both imports are present in every available supported firmware image checked.

## Root cause

VitaStream owns and leaves active a custom UVC UDCD controller across the early
manual-suspend gate. Sony's later native USB suspend handling does not know that
it must deactivate this custom owner. Connected-host USB bus activity can
therefore immediately wake the Vita.

## Implemented policy

At system event `0x100`, the handler synchronously asks VitaStream's worker to:

1. stop audio capture;
2. cancel video capture;
3. restore the local display policy;
4. deactivate UDCD;
5. stop the VitaStream UVC driver;
6. stop `USBDeviceControllerDriver`;
7. release video buffers only after the controller is down.

The handler allows suspend only after the worker acknowledges quiescence. An
error or timeout vetoes that suspend attempt and queues restoration rather than
leaving a partially stopped controller. Capture pacing, audio start and USB
recovery are suppressed while quiesced.

The native resume event `0x100000` is intentionally ignored. VitaStream queues
its own restart only at final event `0x400000`, after Sony has completed native
USB recovery. Event `0x101` restores capture if suspend is aborted. Active USB
storage remains authoritative, and failed restarts remain queued for retry.

## Verification limits

The lifecycle is covered by sanitized host tests and the resulting ARM imports
are verified against available firmware. These tests do not emulate USB
physical-layer wake behavior or a real Vita suspend cycle. Physical confirmation
from the original reporter is still required before considering the fix proven.
