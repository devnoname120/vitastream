VitaStream issue #11 manual-suspend test candidate — 2026-11-07

This is a test build for:
https://github.com/devnoname120/vitastream/issues/11

It is not a release and has not been tested on physical hardware by the author.
The source fix is commit da068cf95842a93dee82682b5bff4ea21219f457 on
branch fix/issue-11-manual-suspend. It is based on main commit
935acb1ec203c59082896b3084be30fef5486ae8, which contains the tested issue #8
VitaShell USB handoff and automatic-resume work.

Diagnosis
---------

Sony's retail 3.65 suspend manager first dispatches system event 0x100. The
native USB service performs later USB-specific work, but does not deactivate
VitaStream's custom UVC UDCD controller at that early gate. With a Windows host
and cable connected, the still-active controller can react to host USB bus
traffic and wake the Vita immediately.

The candidate registers an early system-event handler. Before allowing suspend,
it asks VitaStream's existing worker to stop audio, cancel video, deactivate
UDCD, stop the custom UVC driver and stop USBDeviceControllerDriver. It restarts
capture only after Sony's final resume event 0x400000. Suspend abort, drain
failure, storage ownership and restart retry paths are guarded separately.
`nosleep=on` may remain enabled: it only refreshes the automatic-suspend idle
timer and is not used to override a manual suspend request.

Files
-----

- vitastream.skprx: normal optimized test build; use this first.
- vitastream_diagnostic.skprx: troubleshooting build that writes diagnostics.
- Matching ELF files with symbols.
- vitastream.cfg: example configuration; keep your existing file unless needed.
- source.tar.gz: complete corresponding source tree at the source commit.
- STATIC-ANALYSIS.md: firmware evidence and implementation rationale.
- firmware-matrix.json: import/profile validation receipt.
- host-tests.log and build logs: sanitized host and target-build receipts.
- build-info.json and SHA256SUMS: provenance and file hashes.

Installation
------------

1. Replace the existing VitaStream plugin file with `vitastream.skprx` at the
   same kernel-plugin path. Do not install both variants.
2. Keep the existing taiHEN configuration entry and existing vitastream.cfg.
3. Reboot the Vita once so this test build is loaded.
4. Confirm USB video/audio capture works before testing suspend.

Requested tests for @0lorak
----------------------------

Use the same PS Vita 1000 / firmware 3.65 setup that reproduced issue #11.
First avoid VitaShell USB storage so suspend behavior is isolated.

A. Host capture active

1. Keep the USB cable connected to the Vita and Windows computer.
2. Open the usual Windows video and audio capture sources and confirm both work.
3. Press the Vita power button once to suspend.
4. Do not touch the Vita for at least 20–30 seconds.
5. Confirm whether it remains asleep. A temporary host USB disconnect is
   expected because the candidate deliberately turns off the custom controller.
6. Intentionally wake the Vita with the power button.
7. Check whether USB video and audio return. Windows Camera or the audio source
   may need reopening after USB re-enumeration.
8. Repeat twice without rebooting between cycles.

B. VitaShell standby

Repeat the same sequence using VitaShell's standby command instead of the power
button. Again wait at least 20–30 seconds before intentionally waking it.

C. Cable connected, host sources closed

Close the Windows capture applications but leave the cable connected. Repeat
power-button suspend and intentional wake. This distinguishes active host reads
from ordinary connected-bus traffic.

D. Controls and regression checks

- Repeat once with the cable unplugged.
- After the suspend tests, verify issue #8 still works: start capture, enter
  VitaShell USB storage, stop storage, and confirm automatic capture restoration.
- Launch one ordinary Vita application after a resume to check normal operation.

Failure diagnostics
-------------------

If the Vita still wakes immediately, remains black after intentional wake,
reboots, or capture does not return:

1. Replace the normal module with `vitastream_diagnostic.skprx`.
2. Reboot.
3. Reproduce the shortest failing sequence once.
4. Before rebooting again, copy and attach:

   ux0:/data/vitastream_diag.txt

The diagnostic file is reset on each boot. Please report the exact test step,
whether the host capture applications were open, how long the Vita stayed
asleep, whether the USB device disappeared/re-enumerated, whether video and
audio returned, and any error code or reboot.

Verification performed before packaging
----------------------------------------

- Full AddressSanitizer/UndefinedBehaviorSanitizer host suite passed.
- Default, diagnostic, debug, debug+diagnostic and single-buffer Vita target
  variants compiled with pinned VitaSDK image:
  vitasdk/vitasdk@sha256:fd82d88ff456d118eef16533ebf9a3a6ae0e292684fb8a3a35f15f0707b4692d
- Linked imports, including the system-event register/unregister NIDs, were
  checked against 31 available retail/testkit/devkit firmware combinations from
  3.60 through 3.74 plus the internal 3.650.000 tool image.
- Official retail 3.65 ScePower and SceUsbServ were independently inspected for
  event ordering and USB phase behavior.
- No device installation, suspend cycle or other hardware test was performed.
