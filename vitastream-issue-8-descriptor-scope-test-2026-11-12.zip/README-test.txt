VitaStream issue #8 descriptor-scope test - 2026-11-12

Baseline is 70c77f54bc78a508ade557c232c749f5e12f3371 plus the November 10
diagnostics and one descriptor ownership fix. The shared SceUdcd serializer
hook previously inserted VitaStream's eight-byte video interface association
descriptor into every matching serialized configuration, including other
USB drivers. It now applies that insertion only to configurations retaining
VitaStream's extra-descriptor pointer and length, including native clones. Foreign serialized bytes retain
the native result. VitaStream also declares the eight IAD bytes before native
cache allocation, then fills that reservation without increasing the serialized
length afterward. This keeps insertion inside the native cache region.

Static retail 3.65 analysis confirms this serializer is shared, ignores
configuration-level extras, and uses driver-supplied configurations. Its
cache builder lays out serialized regions with 64-byte alignment. Inserting
eight bytes into a foreign configuration can invalidate that driver's layout
and can overlap a following region when the native length fills its slot.

This fixes a concrete cross-driver descriptor defect. The provided failing
storage log has no handoff result or faulting PC, so hardware testing is still
needed to determine whether it resolves the reporter's SELECT reboot.
The candidate excludes the experimental suspend handler and enlarged-buffer
allocation comparison.

One storage check
-----------------
1. Back up the active plugin, replace that same kernel-plugin file with this
   ZIP's vitastream_diagnostic.skprx, keep your config and reboot once.
   Load one streaming plugin.
2. First verify normal VitaStream video/audio can open in LiveArea. Then close
   all PC Vita capture clients before opening VitaShell.
3. Press SELECT for USB storage once. If it reboots or errors, stop and save
   both ux0:/data/vitastream_diag.txt and vitastream_diag.previous.txt before
   another manual reboot. Report the point where it failed.
4. If storage opens, copy one small file, stop storage, return to LiveArea,
   and check that reopening capture restores video/audio. Save the log.

The normal vitastream.skprx is also included. Use the diagnostic for this
first comparison. Source, patch, checksums and validation logs are included.

Validation
----------
Full ASan/UBSan tests pass, including foreign descriptors with matching
header values, full/high-speed VitaStream IAD insertion, untouched adjacent
bytes and preservation of native serializer errors. Normal/diagnostic builds
pass without warnings. Offline checks pass for 31 available firmware/hardware
pairs; five archive combinations are unavailable. No physical Vita test has
been performed with this candidate. The package retains the narrower tested 70c77f5 baseline for comparison.

Reproduction
------------
Complete corresponding source is in source.tar.gz. Starting at 70c77f5, apply
diagnostics.patch followed by descriptor-scope.patch. Build normally or with:
  make VIDEO_CAMERA_BORROW=1 DIAGNOSTIC=1
SDK image:
  vitasdk/vitasdk@sha256:fd82d88ff456d118eef16533ebf9a3a6ae0e292684fb8a3a35f15f0707b4692d

VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
