VitaStream issue #8 test candidate — 2026-11-07

Built from base commit 211ff77ac105e4bd16d6f4e1b7c53f2e6d62a029 plus the source
changes included in source.tar.gz. This is a test build, not a release.
Compilation succeeded; no automated tests or hardware tests were run.

Changes for issue #8:
- Explicitly yield the USB controller when VitaShell requests USB storage.
- Drain audio/video transfers and return borrowed Camera memory before handoff.
- Keep streaming stopped after handoff until the Vita is rebooted.
- Correct native UDCD state checks (started=2, activated=0x2000).
- Move blocking audio start/attach operations out of USB callbacks. Stop signals
  from callbacks are now atomic and do not wait on a mutex. This addresses the
  0x80027101 callback-context error in the supplied sleep/wake logs; whether it
  also resolves the immediate wake still needs confirmation on the reporter's Vita.

Files:
- vitastream.skprx: normal optimized build, no DEBUG/DIAGNOSTIC logging.
- vitastream_diagnostic.skprx: alternative build with troubleshooting logs.
- vitastream.cfg: optional example; keep your existing configuration.
- source.tar.gz: complete corresponding source, including build files and LICENSE.
- build-info.json: SDK image digest, base commit, source and artifact hashes.
- SHA256SUMS: SHA-256 digests of the included files.

Install ONE plugin variant at the existing kernel plugin path and reboot.
Do not install both variants. Replace the existing file rather than adding a
second VitaStream entry. Use vitastream.skprx first.

Requested checks:
1. Start USB capture, then open VitaShell and press SELECT with USB mode selected.
   Check that Windows detects USB mass storage and file transfers work.
2. End USB storage in VitaShell. Streaming intentionally remains stopped until
   reboot; reboot and confirm video/audio capture returns.
3. With USB connected and VitaStream active again, check manual sleep using the
   power button and VitaShell standby. Please report this result separately.

If either problem remains, install the diagnostic variant instead, reboot,
reproduce it, and attach ux0:/data/vitastream_diag.txt before rebooting again.
The log is reset on each boot.

The candidate also includes the existing unreleased configuration defaults:
screen=on, speakers=on, lowmemory=off, nosleep=on. nosleep concerns automatic
suspend only while capture is active; manual sleep is still intended to work.

VitaStream is based on vita-udcd-uvc by Xerpi, licensed under GPL-3.0.
