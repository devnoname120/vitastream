VitaStream issue #11 timing diagnostic - 2026-11-11

Baseline is corrected suspend candidate cc7b84a6bdc33e17daa6a0d5456a8e7c4635431e.
This adds timing evidence to the existing 0x20F preparation and final-resume
handler. The normal SKPRX is byte-identical to the previously tested candidate.
The diagnostic is separate from main and awaits physical Vita results.

Added records
-------------
- Startup marker: suspend diagnostic schema 0x00000003.
- RTC tick immediately before the existing 0x20F preparation and at final
  0x400000 resume, before capture is restarted. Both API results are logged.
- At final resume, the native raw wake factor from ScePower. Its resolution
  result is recorded at startup. A missing optional getter is recorded as -1.
- Records are copied into the existing bounded callback queue. The video
  worker writes them after resume, preserving the earlier boot log.

On retail 3.65, static inspection shows the native RTC refreshes its offsets
at resume event 0x1000A. The final timestamp is taken after that refresh. The
RTC getter reads its cached offset plus system time. The wake-factor getter
is a plain read of ScePower's saved resume value. Neither getter performs
file I/O or waits in these inspected implementations.

One requested cycle
-------------------
1. Back up the current plugin. Replace the active streaming-plugin file with
   this ZIP's vitastream_diagnostic.skprx and reboot once, retaining one
   streaming plugin and the current config. Verify the new schema marker.
2. In LiveArea, start the same video/audio capture used in the previous #11
   run. Stay in LiveArea for this check.
3. Press power once with USB connected. Leave the Vita untouched for 30
   seconds measured on the PC, then press power once to wake intentionally.
   Note if capture restarts by itself before that button press and whether
   the blue PS light stays lit. Check both capture sources after waking.
4. Save ux0:/data/vitastream_diag.txt and vitastream_diag.previous.txt before
   another manual reboot. Report the approximate measured waiting time.
   Stop after an error instead of repeating the cycle.
5. Restore the backed-up plugin after collecting the evidence if needed.

The measurement uses these pairs of records:
  system timing event 0x0000020F   (preparation)
  system timing event 0x00400000   (final resume)
  system RTC result 0x00000000    (timestamp valid)
  system RTC tick low 0x........
  system RTC tick high 0x........
For each timestamp, combine (high << 32) | low. Subtract the preparation tick
from the final-resume tick and divide by 1000000 for seconds. The interval
includes preparation and native resume work as well as any suspended period.
A nonzero RTC result makes that timestamp unusable. The final resume record
contains the new system wake factor raw value; the preparation placeholder is 0.
Timing and raw wake factor help locate an immediate resume. They do not
measure current draw or establish the hardware's exact power state alone.

Validation and source
---------------------
- Full ASan/UBSan host suite passed, including immutable deferred timestamp
  records, the two 32-bit halves, raw wake factor and RTC error propagation.
- Normal and diagnostic target builds passed without warnings.
- Normal binary equality to cc7b84a is recorded in build-info.json.
- Offline selectors/import checks passed for 31 available firmware/hardware
  pairs, including RTC imports and the dynamically resolved power getter.
  Five firmware/archive combinations were unavailable. The power/RTC code
  analysis above was performed on retail 3.65.
- No physical Vita test was performed with this diagnostic build.

Complete corresponding source is in source.tar.gz. timing-diagnostic.patch
applies to cc7b84a. Build with:
  make VIDEO_CAMERA_BORROW=1 DIAGNOSTIC=1
Pinned SDK image:
  vitasdk/vitasdk@sha256:fd82d88ff456d118eef16533ebf9a3a6ae0e292684fb8a3a35f15f0707b4692d

VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
