VitaStream issue #8 automatic-resume test candidate — 2026-11-07

This replaces the earlier issue #8 candidate that required a reboot after
switching to USB storage. It is a test build, not a release.

New behavior:
- VitaShell USB storage pauses VitaStream and takes the USB controller.
- Closing storage queues automatic VitaStream restoration after VitaShell's
  MTP restoration call completes. No reboot is needed between mode changes.
- The request survives unplugging and temporary activation failures. VitaStream
  can arm itself while disconnected, or retry later if the bus is unavailable.
- Replugging while storage is still running does not take ownership from it.
- A new storage request cancels a pending restoration, and each session uses
  a fresh transfer-drain acknowledgement.

The earlier USB state corrections and nonblocking audio callback changes are
included. The immediate-wake symptom has not been established as fixed.

Files:
- vitastream.skprx: normal optimized build, no DEBUG or DIAGNOSTIC logging.
- vitastream_diagnostic.skprx: alternative build with troubleshooting logs.
- vitastream.cfg: optional example; keep your existing configuration.
- source.tar.gz: complete corresponding source, build files and GPL-3.0 LICENSE.
- build-info.json: SDK image digest, base commit and source/artifact hashes.
- SHA256SUMS: SHA-256 digests of the included files.

Install ONE variant at the existing kernel plugin path and reboot ONCE to load
this candidate. Replace the old plugin file; do not add another plugin entry.
Use vitastream.skprx first. Do not install both variants.

Please check these sequences without rebooting between mode changes:
1. Start USB capture -> VitaShell SELECT/USB -> verify storage/file transfer ->
   stop USB storage -> verify VitaStream video/audio capture returns.
2. VitaShell SELECT/USB -> unplug cable -> stop USB storage -> replug cable ->
   verify VitaStream video/audio capture returns.
3. VitaShell SELECT/USB -> unplug -> replug while storage is still active ->
   verify it remains storage -> stop storage -> verify VitaStream returns.
Repeat the switches to check more than one storage session.

Windows may need its Camera preview or audio capture source reopened after
USB re-enumeration. This is separate from re-enabling VitaStream on the Vita.
Please also report manual sleep/wake behavior separately.

If a problem remains, replace the normal variant with the diagnostic variant,
reboot, reproduce the shortest failing sequence, and attach
ux0:/data/vitastream_diag.txt BEFORE rebooting again; the log resets on boot.

Both variants compiled successfully using the pinned SDK image in build-info.json.
NO automated tests or hardware tests were run. This candidate is untested.

The source snapshot also includes the previously pending configuration defaults:
screen=on, speakers=on, lowmemory=off, nosleep=on. nosleep controls automatic
suspend only while capture is active; manual sleep is intended to work.

VitaStream is based on vita-udcd-uvc by Xerpi, licensed under GPL-3.0.
