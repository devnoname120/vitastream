VitaStream issue #9 allocation comparison - 2026-11-11

This diagnostic comparison tests the remaining allocation-size hypothesis.
Source baseline is 70c77f54bc78a508ade557c232c749f5e12f3371 plus the November 10
issue #9 diagnostics and allocation-comparison.patch. The unmodified normal
build is byte-identical to that baseline. The experiment is outside main.

The diagnostic plugin always allocates 0x152000 bytes (1352 KiB) for its owned
video buffer, including at 480x272. Conversion dimensions, frame pacing and
USB packet size still follow the host's negotiated mode. At 480x272/30,
the video workload matches the successful report while the allocation matches
the failing 720p/30 report. The optional Camera path remains in the build;
it was unavailable in both of this reporter's 3.65 logs.

One comparison
--------------
1. Back up the installed streaming plugin. Replace that active kernel-plugin
   file with this ZIP's vitastream_diagnostic.skprx and reboot once. Keep one
   streaming plugin, the same configuration as the working 480x272 run, and
   EQVita disabled for this comparison. Keep all PC Vita audio clients closed.
2. Start exactly the same FFmpeg video-only capture at 480x272 and 30 fps:
   ffmpeg -f dshow -video_size 480x272 -framerate 30 -pixel_format nv12 -i video="vitastream" -an -f null -
3. Before launching Mario, verify the input is 480x272/30 and the log includes
   diagnostic owned allocation floor 0x00152000
   owned video allocation requested bytes 0x00152000
   video allocated buffers 0x00000001
   UVC COMMIT width 0x000001E0 / height 0x00000110
   Keep USB audio closed. If these conditions are not met, send the setup/log
   rather than continuing the comparison with different conditions.
4. Launch Mario Galaxy v1.4 and load the same save once. Record whether it
   launches and plays, fails before launch, or reboots. Stop after a failure.
5. Save ux0:/data/vitastream_diag.txt and vitastream_diag.previous.txt before
   another manual reboot. Restore the backed-up plugin after collecting them.

A failure with the large allocation at 480x272 would implicate allocation
size or placement. A successful run would leave the higher-resolution video
processing/transfer paths to investigate. Either outcome still requires
interpretation and does not locate a fatal instruction on its own.

This intentionally retains 1352 KiB while capturing lower resolutions.
Use this ZIP only for the issue #9 allocation comparison. For the EQVita
issue #12, use the normal-allocation November 10 diagnostic instead.

Validation and source
---------------------
- Full ASan/UBSan host suite passed, including a comparison-specific test
  proving 480x272-sized USB submissions from the padded allocation, failure
  without pool fallback, cleanup and pending-DMA buffer retention.
- Normal and diagnostic target builds passed without compiler warnings.
- Normal SKPRX is byte-identical to baseline (SHA-256 in build-info.json).
- Compile guards reject the experiment without DIAGNOSTIC or kernel-pool use.
- No physical Vita test has been performed with this comparison build.

Complete corresponding source is in source.tar.gz. Starting from baseline,
apply diagnostics.patch and then allocation-comparison.patch. Build with:
  make VIDEO_CAMERA_BORROW=1 DIAGNOSTIC=1 DIAGNOSTIC_ALLOC_720P=1
SDK image:
  vitasdk/vitasdk@sha256:fd82d88ff456d118eef16533ebf9a3a6ae0e292684fb8a3a35f15f0707b4692d

VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
