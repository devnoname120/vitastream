VitaStream revised issue #11 suspend candidate — 2026-11-10

Source: 758580f955cb8c4ccaaeb14d71bcdd46af3105e7
Branch: fix/issue-11-manual-suspend
This is a test candidate, not a release or confirmed full-suspend fix.

Why this revision
-----------------
The reporter confirmed that current-main's VitaShell-only MtpIf hooks restore
software reboot/power-off, while manual sleep leaves the PS light on and USB
audio cannot restart. The wake log records both monitor modes at 0, a failed
monitor drain (-2) and repeated audio-start timeouts.

This revision updates the separate suspend candidate onto main 51d66bf,
retaining the corrected storage-specific interception, audio startup settling
and the Adrenaline timing change. It does not restore the old generic MTP hook.
The earlier issue #11 ZIP remains withdrawn; this is a different source build.

Policy
------
The early system event 0x100 asks the worker to stop capture and the custom USB
controller before Sony's later audio/USB suspend phases. Restart is delayed
until final resume event 0x400000; suspend abort queues restoration separately.
An audio-drain failure now vetoes successful quiescence instead of being merely
logged. A still-started custom UVC driver after Stop also fails quiescence.
These checks cannot by themselves prove that the hardware entered full suspend.

Diagnostics
-----------
The diagnostic variant records the relevant system-event directions/IDs, audio
drain, USB deactivation/stop results and custom-driver states. Callback events
are queued without filesystem I/O. The worker does not flush the queue while
quiesced; later power-phase records are written after resume.
It also retains one previous boot log at:
  ux0:/data/vitastream_diag.previous.txt
The current file is:
  ux0:/data/vitastream_diag.txt
The startup log contains: suspend diagnostic schema 0x00000001.

One controlled first test
-------------------------
1. Back up the active plugin. For this first test use vitastream_diagnostic.skprx
   at the existing active VitaStream kernel-plugin path. Keep your configuration,
   install only one streaming plugin, and reboot once.
2. From LiveArea, start Windows video and audio capture. Verify both work.
   Do not use VitaShell USB storage or start a PSP/PS1 game in this first cycle.
3. Press the power button once and leave the cable connected for 30 seconds.
   Report whether the screen turns on by itself and whether the PS light
   eventually goes out. The custom USB video/audio device is deliberately
   deactivated; a cached Camera switch icon alone is not a USB-state measurement.
   If available, note the USB disconnect sound or actual Device Manager change.
4. Intentionally wake with the power button. Check video and audio. If one is
   missing, reopen that PC capture source once without rebooting the Vita and
   report whether this restores it.
5. Retrieve the current log and the previous log if present before another
   manual reboot. Report the observed behavior even if everything works.
   If sleep is aborted or capture fails, stop rather than repeating stress tests.
6. After saving those files, check one software reboot from VitaShell, since
   the previously fixed power transition must not regress.

Restore the previous known-working plugin and reboot after collecting evidence
if this candidate makes ordinary use unreliable. No full test matrix is needed.

Validation
----------
The complete ASan/UBSan host suite passes. Tests cover audio-drain failure,
false-success driver stop, suspend/abort/resume/retry, storage exclusion and
callback-safe deferred logging. Normal and diagnostic target builds pass without
compiler warnings in the pinned VitaSDK image; linked imports/profiles were
checked against 31 available firmware/hardware combinations (five unavailable).
No physical Vita test has been performed with this revised candidate.

Normal SKPRX SHA-256: 63eab1f94dc7087489c2b586e07f285ec6962ea42a7589ddaaaae6e2e0065b62
Diagnostic SKPRX SHA-256: 5d8e74614134eb4abb44567bcf103449d70d5913ab969243bdb3659f95639081
The ZIP includes full corresponding source, licence, checksums and receipts.
VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
