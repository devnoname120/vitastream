#include <stdint.h>
#include <stdlib.h>
#define TRANSFORM_DIS_VERBOSE 1
#include "transform-dis.c"
int main(int argc, char **argv) {
    if (argc != 4) return 2;
    unsigned char input[32]={0}, output[512]={0};
    FILE *in=fopen(argv[1],"rb"); if(!in)return 3;
    size_t n=fread(input,1,sizeof input,in); fclose(in); if(n<12)return 4;
    struct arch_dis_ctx arch; arch_dis_ctx_init(&arch);arch.pc_low_bit=true;
    uint_tptr pc=(uint_tptr)strtoul(argv[2],0,0),end=pc+8;
    void *out=output;int offsets[64]={0};
    int result=transform_dis_main(input,&out,pc,&end,0x82000000,&arch,offsets,0);
    printf("result=%d consumed=%u rewritten=%zu\n",result,end-pc,(unsigned char*)out-output);
    FILE *file=fopen(argv[3],"wb");if(!file)return 5;
    fwrite(output,1,(unsigned char*)out-output,file);fclose(file);return result;
}
