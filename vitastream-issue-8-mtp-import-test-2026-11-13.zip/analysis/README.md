# MTP wrapper interworking relocation defect

Source: taiHEN's dependency yifanlu/substitute at 4713452731dd489c13c9415c3c31637845f108f3. The reporter's installed taiHEN binary/version and actual panic PC were not captured. This is a deterministic source-level defect and candidate explanation of the trace, pending hardware confirmation.

Retail 3.65 MtpIf Stop is Thumb at 0x810006E4. Its BLX-immediate at +6 calls ARM import stub 0x81000DB8. The 8-byte entry patch forces relocation through that complete 4-byte BLX, consuming 10 bytes. The decoder fails to word-align its PC, computing 0x81000DBA. The transformer then adds the source Thumb bit and emits a call to 0x81000DBB (Thumb). Correct is 0x81000DB8 (ARM). Start has the same defect: emitted 0x81000E2B versus correct ARM 0x81000E28.

The actual pinned transform_dis_main was compiled with FORCE_TARGET_arm and invoked with native wrapper bytes, pc_patch_end=start+8, Thumb=true and relaxed options=0. Both calls report success while emitting invalid destinations. Raw logs and the standalone harness are included. The last ten output bytes are MOVW LR, low16; MOVT LR, high16; BLX LR. No device was used.

Reproduction: check out the pinned substitute source, compile relocation-repro.c with -DFORCE_TARGET_arm and its lib/include paths, extract at least 12 bytes at each native wrapper from your own decrypted ELF, then run:

    ./relocation-repro stop-prefix.bin 0x810006e4 stop-trampoline.bin
    ./relocation-repro start-prefix.bin 0x810006cc start-trampoline.bin

No firmware ELF is included. The harness calls the real external relocator.

The workaround hooks ARM imports inside SceMtpIfDriver, preserving native kind=1 validation. Validated return-PC checks and VITASHELL title checks exclude other import callers. Wrapper shapes, BLX targets, import NIDs and ARM stub mode pass against 31 available firmware/hardware pairs. Host tests require import-only MTP publication, argument-free native calls, bounded wrapper validation, caller gates, failure recovery and hook lifetime.

Sources:
- https://github.com/yifanlu/taiHEN/blob/master/.gitmodules
- https://github.com/yifanlu/substitute/blob/4713452731dd489c13c9415c3c31637845f108f3/lib/arm/dis-thumb2.inc.h#L181-L186
- https://github.com/yifanlu/substitute/blob/4713452731dd489c13c9415c3c31637845f108f3/lib/arm/arch-transform-dis.inc.h#L197-L205
