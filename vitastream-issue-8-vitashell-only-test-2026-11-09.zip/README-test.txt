VitaStream issue #8: VitaShell-only USB handoff candidate — 2026-11-09

This candidate corrects the overly broad USB handoff in main commit 935acb1.
It is a test build, not a release. NO automated tests or hardware tests were run.

Changes:
- Hook SceMtpIfDriver's argument-taking Start/Stop wrappers, not the shared
  low-level SceUsbMtp lifecycle used during system/app/power transitions.
- Only kind=1 calls from the process with title ID VITASHELL can yield capture
  or request automatic restoration. Sony's normal CMA requests cannot trigger
  VitaStream's storage handoff or storage-recovery state changes.
- Missing optional storage hooks no longer prevent normal capture startup;
  the worker retries installing the hooks once per second.
- Keep VitaShell storage handoff, automatic capture restoration, disconnected
  restoration and retry behavior.

Files:
vitastream.skprx                  Normal optimized build, no DEBUG/DIAGNOSTIC logs.
vitastream_diagnostic.skprx       Alternative build with troubleshooting logging.
vitastream.cfg                   Optional example; keep your existing config.
source.tar.gz                    Complete matching GPL-3.0 source/build files.
fix.patch                        Changes against source base commit 935acb1.
build-info.json                  Pinned SDK digest, base commit and source hashes.
SHA256SUMS                       SHA-256 digests of the included files.

Install ONE variant at your existing plugin path, replacing the previous file,
and reboot once. Do not add a second VitaStream entry or install both variants.
Use the normal build first. Rebooting is required to replace resident hooks.

Requested hardware checks:
1. In LiveArea, plug/unplug/replug USB without opening VitaShell storage.
   Check that VitaStream video/audio enumerates and the CMA USB-connecting
   popup does not replace capture. Repeat while a game is open.
2. Open VitaShell -> SELECT/USB -> transfer a file -> stop USB storage.
   Capture should return without rebooting. Repeat for a second session.
3. Start storage -> unplug -> reconnect after storage ends. If VitaShell does
   not automatically end storage on unplug, stop it before reconnecting.
   Capture should return after reconnection.
4. Check normal app launch plus software reboot/power-off from VitaShell or
   HENkaku Settings. The low-level MTP shutdown routine is no longer hooked.

The previous storage candidate was confirmed on a PS Vita 1000 / 3.65, but that
feedback does not validate this revised hook/caller policy. Other outstanding
application-launch and manual-wake problems are not claimed fixed by this build.

If the problem remains, replace the normal file with the diagnostic alternative,
reboot, reproduce the shortest failing sequence, and save
ux0:/data/vitastream_diag.txt BEFORE another reboot, which resets the log.

Windows/OBS may need a capture source reopened after real USB re-enumeration.
The code changes are local to this candidate; main/release publication is separate.

VitaStream is based on vita-udcd-uvc by Xerpi, licensed under GPL-3.0.
