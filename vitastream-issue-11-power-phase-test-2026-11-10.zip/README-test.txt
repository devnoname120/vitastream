VitaStream issue #11 corrected power-phase candidate — 2026-11-10

Source: cc7b84a6bdc33e17daa6a0d5456a8e7c4635431e
Branch: fix/issue-11-manual-suspend; main base 51d66bf
Intended first test: the reporter's retail Vita on firmware 3.65.
This is an experimental test build, not a release or a confirmed suspend fix.
The earlier November 7 and November 10 issue #11 packages are withdrawn.

What the failed test established
--------------------------------
The logs show event 0x100, abort 0x101, and only then worker quiescence and a
USB restart. Audio returned after an aborted transition; full suspend was
not demonstrated. Software reboot/power-off regressed with that candidate.

Official 3.65 ScePower masks IRQs before the vetoable 0x100 dispatch. The
native SysEvent dispatcher preserves that incoming IRQ state while invoking
handlers. The 3.65 event-flag wait rejects an IRQ-masked caller with 0x80028004.
ScePower aborts on the negative initial gate result. The old candidate waited
in that masked phase, so the worker's later success could not validate sleep.

This revision leaves 0x100 nonblocking. It prepares the custom USB path at
0x20F, after ScePower restores IRQs and before the native 0x200 USB phase and
0x1000 audio queue reset. It checks the IRQ mask at runtime before waiting.
Preparation has a bounded wait, and errors are logged without vetoing the
native transition. After expiry the worker skips subsequent teardown steps.
Capture remains suppressed until abort or final native resume (0x400000).
The VitaShell-only MTP correction remains in place.

One controlled first test
-------------------------
1. Back up the active plugin. Replace it with vitastream_diagnostic.skprx at
   the same configured path, keep your settings, load one streaming plugin,
   and reboot once. The new marker is suspend diagnostic schema 0x00000002.
2. Start video and audio from LiveArea, verify both, and press the power
   button once with USB still connected. Wait 30 seconds. Record whether the
   screen wakes, whether the PS light goes out and any actual USB disconnect.
3. Intentionally wake and check both sources. If one is missing, reopen that
   PC source once without rebooting the Vita and report the difference.
4. Save ux0:/data/vitastream_diag.txt and vitastream_diag.previous.txt if present.
   The log now distinguishes 0x100, 0x20F, the raw wait result, native audio/USB
   phases and final resume. A successful worker stop alone is not proof of sleep.
5. After saving the files, check one software reboot. Stop on a failure and
   restore the known-working baseline; no full test matrix is requested.

Verification
------------
Full ASan/UBSan host suite, normal/diagnostic target builds and 31 available
firmware/hardware import/profile checks passed. Five archive combinations
were unavailable. The power-phase analysis above is from retail 3.65; the
firmware matrix is not a claim of identical hardware suspend behavior.
No physical Vita was tested with this candidate.

Complete matching source, licence, checksums and build receipts are included.
VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
