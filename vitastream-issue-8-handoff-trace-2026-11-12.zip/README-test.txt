VitaStream issue #8 handoff tracing diagnostic - 2026-11-12

This records where the remaining VitaShell storage transition stops. It is
based on the November 12 descriptor candidate. The normal build is byte-identical
to that candidate. Existing handoff order, retry policy and scope are preserved.
Only vitastream_diagnostic.skprx is supplied for this tracing test.

The descriptor ownership/reservation fix remains included, but the reporter's
SELECT failure persisted with that fix. This is additional instrumentation.

One attempt
-----------
1. Close Windows Camera, OBS, FFmpeg and the Windows sound-input preview. Keep
   host capture closed from boot through the storage attempt.
2. Back up the active streaming plugin. Replace that same file with this ZIP's
   vitastream_diagnostic.skprx, keep the config and reboot once. Load one variant.
   Check the startup marker USB handoff trace schema 0x00000001.
3. Open VitaShell and press SELECT once. If application launch itself errors,
   save the logs and report that point. Stop after the first error/reboot.
4. Save ux0:/data/vitastream_diag.txt and vitastream_diag.previous.txt before
   another manual reboot. Report whether SELECT caused a console reboot, a
   displayed error, or USB storage simply failed to appear. If storage works,
   save that result and the logs. Restore the backed-up plugin after collecting
   the evidence if needed.

Records
-------
MtpIf wrapper records carry the kind, caller PID, stage and return value.
They use the existing bounded nonblocking queue. The worker writes them later.
Stage ids:
  1 stop entry            2 VitaShell scope accepted
  3 mutex acquired        4 wait for worker begins
  5 wait result           6 native MTP stop begins
  7 native MTP stop result
  8 fallback controller start result
  9 fallback MTP start result
 10 native retry result  11 stop hook exit

The video worker also writes before/after records for audio stop/drain, video
cancellation/release, screen restore, deactivation, protocol/controller stop
and the ready acknowledgement. These worker records help identify a call that
never returns. No filesystem output is added to the queued wrapper producer.
A fatal error before queued records flush may still leave the last operation
unknown; absence of a final record is not a faulting-PC trace.

Validation
----------
Full ASan/UBSan suite passed, including deferred handoff record values and no
callback file I/O. Normal/diagnostic target builds passed without warnings.
The normal binary is byte-identical to the descriptor candidate. Offline checks
passed for 31 available firmware/hardware pairs; five archive combinations were
unavailable. No physical Vita test was performed with this tracing build.

Complete corresponding source is in source.tar.gz. Starting at 70c77f5, apply
 diagnostics.patch, descriptor-scope.patch, then handoff-trace.patch.
Build with make VIDEO_CAMERA_BORROW=1 DIAGNOSTIC=1 in the pinned image
 vitasdk/vitasdk@sha256:fd82d88ff456d118eef16533ebf9a3a6ae0e292684fb8a3a35f15f0707b4692d.

VitaStream is based on vita-udcd-uvc by Xerpi and is licensed under GPL-3.0.
